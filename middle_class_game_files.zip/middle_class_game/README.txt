MIDDLE CLASS GAME
1) Test: open index.html in a browser (best through a local web server).
2) Publish free: create a GitHub account, create a public repository named middle-class-game, upload index.html, manifest.json and sw.js. In repository Settings > Pages, choose Deploy from a branch, branch main, folder /(root), Save. Wait for the published URL.
3) Android: open the published HTTPS URL in Chrome on Android and use menu > Install app / Add to Home screen. This creates an installable app-like version. For a store-ready APK/AAB, use PWABuilder with the published URL and follow its Android package flow; signing and Play Store publishing require your own developer account.
Controls: keyboard arrows/A-D + Space, or on-screen buttons.
